import numpy as np
from scipy.integrate import solve_ivp


"""
    System class representing the Duffing oscillator, with functions to evaluate
    the vector field of the associated ODE and to produce simulation data.
"""

class Duffing:

    def __init__(self, alpha, beta, delta):
        """
            alpha, beta, gamma: system constants
        """
        self.alpha = alpha
        self.beta = beta
        self.delta = delta

    def vector_field(self, x, u):
        """
        Evaluate the vector field of the Duffing oscillator with control input u
        (see README for definition).

        x:  array (2,) or (2, N):   position(s) to evaluate the Duffing vectot field at
        u:  float                   control input
        """
        # Evaluate vector field for one position...
        if len(x.shape) == 1:
            FX = np.zeros(2)
            FX[0] = x[1]
            FX[1] = (-self.delta * x[1] - self.alpha * x[0] * u 
                        - 2 * self.beta * x[0]**3)
        # ... or for multiple positions:
        else:
            FX = np.zeros((2, x.shape[1]))
            FX[0, :] = x[1, :]
            FX[1, :] = (-self.delta * x[1, :] - self.alpha * x[0, :] * u 
                        - 2 * self.beta * x[0, :]**3)
        
        return FX

    def simulate(self, x0, dt, m, u):
        """ 
        Produce simulation of the Duffing oscillator.

        Parameters:
        -----------
        x0, (2,) or (2, N):       
                        initial position(s)
        dt, float:      integration time step
        m, int:         number of time steps
        u, callable or float
                        control input, can be constant or a callable function
                        of time

        Returns:
        --------
        y, (2, m+1) or (2, m+1, N)
                        simulation trajectory(ies)
        times, (m+1)    time grid on which the simulation is evaluated.
        """
        # Check if control is constant:
        if isinstance(u, float):
            u0 = u
            u = lambda t: u0
        # Check if multiple initial conditions were supplied:
        if len(x0.shape) == 1:
            x0 = x0[:, None]
        N = x0.shape[1]
        # Right hand side:
        _ode_rhs = lambda t, x: self.vector_field(x, u(t))
        # time steps for evaluation:
        tvec = np.linspace(0, m*dt, m+1)
        # Produce simulations:
        Y = np.zeros((2, m+1, N))
        for ii in range(N):
            Y[:, :, ii] = solve_ivp(_ode_rhs, (tvec[0], tvec[-1]), x0[:, ii], t_eval=tvec,
                              vectorized=True).y
        if N == 1:
            Y = Y[:, :, 0]

        return (Y, tvec)
