import numpy as np
import scipy.linalg as scl

""" This module provides the functionality required for Koopman learning and
    prediction.
"""

""" Function to learn regularized Koopman matrix from time-shifted data: """
def koopman_matrix(X, Y, Phi, tol):
    """
    Parameters:
    -----------
    X, (d, m):      initial data
    Y, (d, m):      time-shifted data
    Phi:            basis set class
    tol, float:     regularization parameter

    Returns:
    --------
    K, (p, p):      Koopman matrix for the basis set Phi
    """
    # Evaluate the basis set:
    MX = Phi(X)
    MY = Phi(Y)
    p = MX.shape[0]
    # Build regularized Koopman matrix:
    K = scl.pinv(MX @ MX.conj().T + tol*np.eye(p)) @ (MX @ MY.conj().T)
    
    return K

""" Function to perform state prediction with Koopman matrix"""
def prediction_koopman(K, x0, Phi, V, nsteps, dt, dlift=1, u=None):
    """
    Parameters:
    -----------
    K, (p, p) or (2, p, p):      
                    Koopman matrix or matrices for the basis set Phi
    x0, (2, N):     initial conditions.
    Phi:            basis set class
    V, (2, p):      expansion coefficients of state variables (x and y)
                    with respect to basis set.
    nsteps, int:    number of integration time steps.
    dt, float:      integration time step
    dlift, int:     frequency of project-and-lift step.
    u, callable or None:
                    callable for time-dependent control input, or None
                    for no input

    Returns:
    --------
    Z, (p, nsteps+1, N):
                    predicted state $Phi(X_t)$ for all simulation time steps
                    and all dictionary functions.
    """
    # Set u to None if only one Koopman matrix is given:
    if len(K.shape) == 2:
        u = None
    # Default to constant input multiple Koopman models are given.
    elif u is None:
        u = lambda t: 0.0
    # Evaluate basis set at initial conditions:
    z0 = Phi(x0)
    # Prepare output:
    p, ntraj = z0.shape
    Z = np.zeros((p, nsteps+1, ntraj), dtype=complex)
    # Fill in initial conditions:
    Z[:, 0, :] = z0.copy()

    # Use Koopman matrix to evolve system state in time:
    for jj in range(nsteps):
        # Time-dependent Koopman model:
        if u is not None:
            Ku = K[0, :, :] + (K[1, :, :] - K[0, : ,:]) * u(jj*dt)
        else:
            Ku = K
        # Apply update:
        Z[:, jj+1, :] = np.tensordot(Ku.conj().T, Z[:, jj, :].copy(),  axes=([1], [0]))
        # Apply project and lift if required:
        if np.remainder(jj, dlift) == 0:
            XY = np.tensordot(V, Z[:, jj+1, :], axes=([1], [0]))
            Z[:, jj+1, :] = Phi(XY).copy()
    
    return Z


""" Function to benchmark performance for a given list of Koopman models: """
def benchmark_models(K_list, Phi, V, nsteps, dt, Xtest, Ytest, dlift=1):
    """
    Parameters:
    -----------
    Klist, (nm, p, p):      
                    array of nm Koopman models for the basis set Phi
    Phi:            basis set class
    V, (2, p):      expansion coefficients of state variables (x and y)
                    with respect to basis set.
    nsteps, int:    number of integration time steps.
    dt, float:      integration time step
    dlift, int:     frequency of project-and-lift step.

    Returns:
    --------
    Elist, (nm,):
                    mean prediction error for all models, averaged over ntest trajectories
                    comprising nsteps discrete time steps.
    """
    # Number of Koopman models to test:
    nm = K_list.shape[0]
    # Propagate all Koopman models from all initial conditions:
    Elist = np.zeros(nm, dtype=complex)
    for ii in range(nm):
        # Predict with Koopman:
        ztraj = prediction_koopman(K_list[ii, :, :], Xtest.astype(complex), Phi, V, nsteps, 
                                   dt, dlift=dlift)
        # Project onto coordinates:
        k_traj = np.tensordot(V, ztraj, axes=([1], [0]))
        # Compute mean error over all times and trajectories:
        Elist[ii] = np.mean(scl.norm(k_traj - Ytest, axis=0)/scl.norm(Ytest, axis=0))

    return Elist